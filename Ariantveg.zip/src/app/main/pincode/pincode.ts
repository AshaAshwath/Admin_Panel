export class pincode{

    public pincode:any;
    public Area:any;
    public Status :any;
    public pintype :any;

    
}