export class product{

    public productName:any;
    public productCode:any;
    public price :any;
    public discount:any;
    public shortdescription:any;
    public productdescription :any;
    public productimage:any;
    public UOM:any;
    public status:any;
    public ecategory:any;
    public preservationmeaures:any;
    
}
