export class customer{
    public userName:string;
    public userContactNumber:string;
    public userEmail:string;
    public userstreetAddress:string;
    public usercity:string;
    public userState:string;
    public userzipCode:string;
    public userCountry:string;
}
