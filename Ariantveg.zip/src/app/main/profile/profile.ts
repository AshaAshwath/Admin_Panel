export class profile{
    public password:string;
    public password1:string;
}
