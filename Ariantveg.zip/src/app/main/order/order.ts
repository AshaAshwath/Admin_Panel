export class order{
    public shippingadd:string;
    public billaddres:string;
    public edate:any;
    public sdate:any; 

    public OrderID:any;
    public OrderDate:any;
    public CustomerID:any;
    public CustomerName:any;
    public TotalItems:any;
    public TotalAmount:any;
    public Status:any;
    public Action:any;
}