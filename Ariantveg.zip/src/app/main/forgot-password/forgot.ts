export class Forgot{
   
    public email:string;
    public username:string;
    public otp:any;
    public newpassword:string;
    public conpassword:string;
   
}