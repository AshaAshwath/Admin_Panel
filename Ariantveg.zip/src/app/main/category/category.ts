export class category{
    public  categoryName: string;
    public categoryCode: string;
    public description:string;
    public categoryimage:string;
    public status:string;
    }



    